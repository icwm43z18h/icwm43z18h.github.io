---
name: 节点异常或配置报错反馈 (Bug Report)
about: 提交节点连接超时、客户端解析失败或规则异常
title: '[节点/配置报错]: '
labels: 'bug, network'
assignees: ''
---

**客户端环境 (Client Info):**
- 操作系统: [如 Windows 11 / macOS Sequoia / iOS 18 / Android 14]
- 使用客户端: [如 Clash Verge Rev / Shadowrocket / Sing-box / v2rayN]
- 客户端版本号: 

**异常现象描述:**
清晰说明在连接哪个节点（如 HK-BGP-01、US-AI-01）时遇到什么报错（如 `Handshake failed`, `Timeout`, `DNS Leak`）。

**排查自检项 (请确认):**
- [ ] 本地系统时间误差是否在 60 秒以内
- [ ] 本地代理端口是否冲突 (默认 7890/10808)
- [ ] 订阅链接是否能在官方入口正常拉取
